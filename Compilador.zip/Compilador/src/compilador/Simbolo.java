
package compilador;

public class Simbolo{

    int escopo;
    String tipo;
    String valor;
    String lexema;
    String token;
    int linha;
    String oper;

    public Simbolo(){}
    public Simbolo(int escopo, String tipo, String valor) {
        this.escopo = escopo;
        this.tipo = tipo;
        this.valor = valor;
    }
    
}
