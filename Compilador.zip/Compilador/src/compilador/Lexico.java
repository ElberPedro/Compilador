
package compilador;


public class Lexico extends Simbolo{
    
    public Lexico(String token, String lexema, int linha) {
        this.lexema = lexema;
        this.token = token;
        this.linha = linha;
    }

    public String getLexema() {
        return lexema;
    }

    public void setLexema(String lexema) {
        this.lexema = lexema;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getLinha() {
        return linha;
    }

    public void setLinha(int linha) {
        this.linha = linha;
    }
    
}
