
package compilador;


public class Principal {
       public static void main(String[] args) {
        AnaLex Lexico = new AnaLex (); 
        Lexico.AnalizaLexico();
    }
}
